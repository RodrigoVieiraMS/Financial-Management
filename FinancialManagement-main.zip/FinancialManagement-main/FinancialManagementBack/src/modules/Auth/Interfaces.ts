export interface ILoginUser {
    username: string
    name: string,
    password: string,
    email: string
}

export interface IRegisterUser {
    username: string
    name: string,
    password: string,
    email: string
}